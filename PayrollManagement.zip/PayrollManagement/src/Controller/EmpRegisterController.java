
package Controller;

import Model.EmpRegisterModel;


public class EmpRegisterController {
    private EmpRegisterModel empModel;
    
    
    public EmpRegisterController(EmpRegisterModel empModel){
        this.empModel=empModel;
     }
    
    public boolean registerEmployee(int empID, String empName, String paygrp, int age, String gender, double Bsal, double allowance, String emp_type, String job_title){
    return empModel.registerEmployee(empID, empName, paygrp, age, gender, Bsal, allowance, emp_type, job_title);
    }
}    

