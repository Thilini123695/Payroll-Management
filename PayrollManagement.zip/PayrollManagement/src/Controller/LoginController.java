
package Controller;

import Model.LoginModel;


public class LoginController {
    
    private LoginModel model;
    
    public LoginController(LoginModel model) {
        this.model = model;
    }
        public boolean validateUser(String username, String password){
        return this.model.validateUser(username, password);
        }
        public boolean registeruser(int ID,String username,String password){
        return this. model.registeruser(ID, username, password);
        }
    }


