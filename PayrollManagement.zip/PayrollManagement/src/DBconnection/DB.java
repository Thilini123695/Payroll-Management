
package DBconnection;

 import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public  class DB {
    
    public static  Connection getConnection() throws SQLException {
        String jdbc = "jdbc:mysql://localhost:3306/companypayroll";  
        String usr = "root"; 
        String Password = "";
        return  DriverManager.getConnection(jdbc, usr, Password);
    }
     
    
    
}
