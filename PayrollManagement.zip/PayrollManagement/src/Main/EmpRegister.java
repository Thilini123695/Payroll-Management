/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import Controller.EmpRegisterController;
import Model.EmpRegisterModel;

/**
 *
 * @author Thilini.Piyumika
 */
class EmpRegister {
    EmpRegisterModel empModel= new EmpRegisterModel();
    EmpRegisterController empController= new EmpRegisterController(empModel);
    EmpRegister empview=new EmpRegister();
    
    empview.setVisible(true);
}
