
package Main;

import Controller.EmpRegisterController;
import Model.EmpRegisterModel;



public class EmpRegisterMain {
    EmpRegisterModel empModel = new EmpRegisterModel();
    EmpRegisterController empController = new EmpRegisterController(empModel);
   
    
}
