package Main;


import Controller.LoginController;

import Model.LoginModel;
import Views.Login;



public class Main {
    public static void main(String[] args) {

    LoginModel LoginModel = new LoginModel();
    LoginController controller = new LoginController(LoginModel);
    Login view = new Login(controller);

    view.setVisible (true);

    


    }
    
    
}

    
    