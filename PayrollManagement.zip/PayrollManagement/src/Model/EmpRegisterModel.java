
package Model;
import DBconnection.DB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmpRegisterModel {
    
    
    public boolean registerEmployee(int empID, String empName, String paygrp, int age, String gender, double Bsal, double allowance, String emp_type, String job_title) {
    try {
           Connection conn = DB.getConnection();
           
           String sql = "INSERT INTO employee_salary_details (empID, empName, paygrp, age, gender, Bsal, allowance, emp_type, job_title) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setInt(1, empID);               
        pst.setString(2, empName);           
        pst.setString(3, paygrp);            
        pst.setInt(4, age);                  
        pst.setString(5, gender);            
        pst.setDouble(6, Bsal);              
        pst.setDouble(7, allowance);         
        pst.setString(8, emp_type);          
        pst.setString(9, job_title); 
   ResultSet rs = pst.executeQuery();
   
    int rowsAffected = pst.executeUpdate();
            
            if (rowsAffected > 0) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
            return false;
        }
    }
        
}
