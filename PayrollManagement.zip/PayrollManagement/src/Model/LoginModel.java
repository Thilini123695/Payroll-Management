
package Model;







import DBconnection.DB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




public class LoginModel {
    public boolean validateUser(String Username, String Password) {
        
        try {
           Connection conn= DB.getConnection();
            // SQL query to check username and password
            String sql = "SELECT * FROM signin WHERE usrName = ? AND Pass = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
             pst.setString(1, Username); 
             pst.setString(2, Password);
            
            ResultSet rs = pst.executeQuery();
            
            
          if(rs.next()){
          return true;
          }else{
              return false;    
                  }
          
          
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
            return false;
        }
 
    
    
  }

public boolean registeruser(int ID,String username,String password){
    try{
        Connection conn= DB.getConnection();
        String sql = "INSERT INTO signin (empID, usrName, Pass) VALUES (?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        
        pst.setInt(1,ID );          
        pst.setString(2, username); 
        pst.setString(3, password);
        
        int rowsAffected= pst.executeUpdate();
        return rowsAffected>0;
    }catch(SQLException e){
    System.out.println("error:"+ e.getMessage());
    return false;
    
    }
}
}









        




