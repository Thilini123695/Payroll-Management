


package Views;

import Controller.EmpRegisterController;
import Model.EmpRegisterModel;
import javax.swing.*;


public class EmpRegister extends javax.swing.JFrame{ 

   private EmpRegisterController empController;

    public EmpRegister(EmpRegisterController empController) {
       
        this.empController= empController;
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_bsal = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_eid = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txt_ename = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txt_age = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txt_etype = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txt_jtitle = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txt_gender = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txt_alw = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        btn_save = new javax.swing.JButton();
        cmb_pgr = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel2.setText("Employee Registration");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 220, 30));

        jLabel3.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel3.setText("Pay Group");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 110, 30));

        jLabel4.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel4.setText("Allowance");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 130, 90, 30));
        getContentPane().add(txt_bsal, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 80, 220, -1));

        jLabel5.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel5.setText("EmployeeID");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 110, 30));
        getContentPane().add(txt_eid, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, 220, -1));

        jLabel6.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel6.setText("Employee Name");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 130, 30));
        getContentPane().add(txt_ename, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 140, 220, -1));

        jLabel7.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel7.setText("Age");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 170, 40, 30));
        getContentPane().add(txt_age, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 220, -1));

        jLabel8.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel8.setText("Job Title");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 220, 80, 30));
        getContentPane().add(txt_etype, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 180, 220, -1));

        jLabel9.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel9.setText("Employee Type");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 180, 130, 30));
        getContentPane().add(txt_jtitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 220, 220, -1));

        jLabel10.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel10.setText("Gender");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, 110, 30));
        getContentPane().add(txt_gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, 220, -1));

        jLabel11.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel11.setText("Basic Salary");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 80, 110, 30));
        getContentPane().add(txt_alw, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 130, 220, -1));

        jButton1.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        jButton1.setText("Close");
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 330, 70, -1));

        btn_update.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        btn_update.setText("Update");
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });
        getContentPane().add(btn_update, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 290, -1, -1));

        btn_delete.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });
        getContentPane().add(btn_delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 290, -1, -1));

        btn_save.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        btn_save.setText("Save");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });
        getContentPane().add(btn_save, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 290, -1, -1));

        cmb_pgr.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        cmb_pgr.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Company 1", "Company 2", "Company 3" }));
        getContentPane().add(cmb_pgr, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 60, 220, -1));

        jLabel1.setBackground(new java.awt.Color(204, 204, 204));
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 370));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        
        try {
        
        int empID = Integer.parseInt(txt_eid.getText());       
        String empName = txt_ename.getText();                 
        String paygrp = cmb_pgr.getSelectedItem().toString(); 
        int age = Integer.parseInt(txt_age.getText());           
        String gender = txt_gender.getText();                    
        double Bsal = Double.parseDouble(txt_bsal.getText());    
        double allowance = Double.parseDouble(txt_alw.getText()); 
        String emp_type = txt_etype.getText();                
        String job_title = txt_jtitle.getText();              

        
        
       
        if (empController.registerEmployee(empID, empName, paygrp, age, gender, Bsal, allowance, emp_type, job_title)) {
            JOptionPane.showMessageDialog(this, "Employee registered successfully!");
            
           
            

        } else {
            JOptionPane.showMessageDialog(this, "Employee registration failed. Please try again.");
        }

    } catch (NumberFormatException ex) {
        
        JOptionPane.showMessageDialog(this, "Please enter valid data: " + ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
    } 
}
    
        
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
       
    }//GEN-LAST:event_btn_deleteActionPerformed


   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_update;
    private javax.swing.JComboBox<String> cmb_pgr;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txt_age;
    private javax.swing.JTextField txt_alw;
    private javax.swing.JTextField txt_bsal;
    private javax.swing.JTextField txt_eid;
    private javax.swing.JTextField txt_ename;
    private javax.swing.JTextField txt_etype;
    private javax.swing.JTextField txt_gender;
    private javax.swing.JTextField txt_jtitle;
    // End of variables declaration//GEN-END:variables

