
package Views;

import DBconnection.DB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class EmployeeRegisterDetails extends javax.swing.JFrame {

   
    public EmployeeRegisterDetails() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txt_eid = new javax.swing.JTextField();
        txt_ename = new javax.swing.JTextField();
        cmb_pgr = new javax.swing.JComboBox<>();
        txt_age = new javax.swing.JTextField();
        txt_gender = new javax.swing.JTextField();
        txt_bsal = new javax.swing.JTextField();
        txt_alw = new javax.swing.JTextField();
        txt_etype = new javax.swing.JTextField();
        txt_jtitle = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btn_save = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel3.setText("Employee ID");
        jLabel3.setOpaque(true);
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, 140, -1));

        jLabel4.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel4.setText("Employee name");
        jLabel4.setOpaque(true);
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 150, -1));

        jLabel5.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel5.setText("Pay Group");
        jLabel5.setOpaque(true);
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, -1, -1));

        jLabel7.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel7.setText("Age");
        jLabel7.setOpaque(true);
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 50, -1));

        jLabel6.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel6.setText("gender");
        jLabel6.setOpaque(true);
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 80, -1));

        jLabel8.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel8.setText("Basic Salary");
        jLabel8.setOpaque(true);
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, 120, 30));

        jLabel9.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel9.setText("Allowance");
        jLabel9.setOpaque(true);
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(103, 290, 110, -1));

        jLabel10.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel10.setText("Employee Type");
        jLabel10.setOpaque(true);
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 330, -1, -1));

        jLabel11.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel11.setText("Job Title");
        jLabel11.setOpaque(true);
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 370, -1, 30));
        getContentPane().add(txt_eid, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 60, 220, -1));
        getContentPane().add(txt_ename, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 100, 220, -1));

        cmb_pgr.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        cmb_pgr.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Company 1", "Company 2", "Company 3" }));
        getContentPane().add(cmb_pgr, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 140, 220, -1));
        getContentPane().add(txt_age, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 220, -1));
        getContentPane().add(txt_gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 220, 220, -1));
        getContentPane().add(txt_bsal, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 250, 220, -1));
        getContentPane().add(txt_alw, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 290, 220, -1));
        getContentPane().add(txt_etype, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 330, 220, -1));
        getContentPane().add(txt_jtitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 370, 220, -1));

        jLabel1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 18)); // NOI18N
        jLabel1.setText("Employee Details");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 20, 260, -1));

        btn_save.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        btn_save.setText("Save");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });
        getContentPane().add(btn_save, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 140, 150, -1));

        btn_update.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        btn_update.setText("Update");
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });
        getContentPane().add(btn_update, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 200, 150, 30));

        btn_delete.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });
        getContentPane().add(btn_delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 260, 150, -1));

        jButton1.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        jButton1.setText("close");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 400, -1, -1));

        jButton2.setFont(new java.awt.Font("Rockwell Condensed", 1, 18)); // NOI18N
        jButton2.setText("Home");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 400, -1, -1));

        jLabel2.setBackground(new java.awt.Color(153, 153, 153));
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Thilini.piyumika\\Desktop\\PayrollMimages\\How-a-Payroll-System-Works-.png")); // NOI18N
        jLabel2.setOpaque(true);
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 760, 450));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
       Connection connection = null;
    PreparedStatement preparedStatement = null;
        
            try {
        
        int empID = Integer.parseInt(txt_eid.getText());
        String empName = txt_ename.getText();
        String paygrp = cmb_pgr.getSelectedItem().toString(); 
        int age = Integer.parseInt(txt_age.getText());
        String gender = txt_gender.getText();
        double Bsal = Double.parseDouble(txt_bsal.getText());
        double allowance = Double.parseDouble(txt_alw.getText());
        String empType = txt_etype.getText();
        String jobTitle = txt_jtitle.getText();

       
        connection = DB.getConnection();

       
        String sql = "INSERT INTO employee_salary_details (empID, empName, paygrp, age, gender, Bsal, allowance, emp_type, job_title) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        preparedStatement = connection.prepareStatement(sql);

        
        preparedStatement.setInt(1, empID);
        preparedStatement.setString(2, empName);
        preparedStatement.setString(3, paygrp);
        preparedStatement.setInt(4, age);
        preparedStatement.setString(5, gender);
        preparedStatement.setDouble(6, Bsal);
        preparedStatement.setDouble(7, allowance);
        preparedStatement.setString(8, empType);
        preparedStatement.setString(9, jobTitle);

        
        int rowsInserted = preparedStatement.executeUpdate();

        if (rowsInserted > 0) {
            JOptionPane.showMessageDialog(this, "Employee details saved successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to save employee details.");
        }

    } catch (NumberFormatException ex) {
       
        JOptionPane.showMessageDialog(this, "Please enter valid data: " + ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
    } catch (SQLException ex) {
        
        JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        Connection connection = null;
    PreparedStatement preparedStatement = null;

    try {
        
        int empID = Integer.parseInt(txt_eid.getText());
        String empName = txt_ename.getText();
        String paygrp = cmb_pgr.getSelectedItem().toString();
        int age = Integer.parseInt(txt_age.getText());
        String gender = txt_gender.getText();
        double Bsal = Double.parseDouble(txt_bsal.getText());
        double allowance = Double.parseDouble(txt_alw.getText());
        String empType = txt_etype.getText();
        String jobTitle = txt_jtitle.getText();

       
        connection = DB.getConnection();

        
        String sql = "UPDATE employee_salary_details SET empName = ?, paygrp = ?, age = ?, gender = ?, Bsal = ?, allowance = ?, emp_type = ?, job_title = ? WHERE empID = ?";
        preparedStatement = connection.prepareStatement(sql);

        
        preparedStatement.setString(1, empName);
        preparedStatement.setString(2, paygrp);
        preparedStatement.setInt(3, age);
        preparedStatement.setString(4, gender);
        preparedStatement.setDouble(5, Bsal);
        preparedStatement.setDouble(6, allowance);
        preparedStatement.setString(7, empType);
        preparedStatement.setString(8, jobTitle);
        preparedStatement.setInt(9, empID);  // The empID in the WHERE clause

       
        int rowsUpdated = preparedStatement.executeUpdate();

        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, "Employee details updated successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update employee details.");
        }

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Please enter valid data: " + ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        Connection connection = null;
    PreparedStatement preparedStatement = null;

    try {
       
        int empID = Integer.parseInt(txt_eid.getText());

       
        connection = DB.getConnection();

        
        String sql = "DELETE FROM employee_salary_details WHERE empID = ?";
        preparedStatement = connection.prepareStatement(sql);

       
        preparedStatement.setInt(1, empID);

       
        int rowsDeleted = preparedStatement.executeUpdate();

        if (rowsDeleted > 0) {
            JOptionPane.showMessageDialog(this, "Employee deleted successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to delete employee. Employee ID not found.");
        }

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Please enter a valid Employee ID: " + ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       Home frame3= new Home();
       frame3.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployeeRegisterDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployeeRegisterDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployeeRegisterDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployeeRegisterDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployeeRegisterDetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_update;
    private javax.swing.JComboBox<String> cmb_pgr;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txt_age;
    private javax.swing.JTextField txt_alw;
    private javax.swing.JTextField txt_bsal;
    private javax.swing.JTextField txt_eid;
    private javax.swing.JTextField txt_ename;
    private javax.swing.JTextField txt_etype;
    private javax.swing.JTextField txt_gender;
    private javax.swing.JTextField txt_jtitle;
    // End of variables declaration//GEN-END:variables
}
