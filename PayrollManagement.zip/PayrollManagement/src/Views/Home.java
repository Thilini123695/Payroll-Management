
package Views;



import DBconnection.DB;
import java.awt.FlowLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

public class Home extends javax.swing.JFrame {

    
    public Home() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        cmb_pgr = new javax.swing.JComboBox<>();
        txt_eid = new javax.swing.JTextField();
        txt_jtitle = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txt_ename = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txt_bsal = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txt_gender = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txt_etype = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txt_alw = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        btn_search = new javax.swing.JButton();
        txt_age = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 153, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel8.setText("Payroll Actions");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 170, 30));

        jLabel9.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel9.setText("Job Title");
        jLabel9.setOpaque(true);
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 430, 80, 30));

        jButton3.setFont(new java.awt.Font("Rockwell Condensed", 0, 18)); // NOI18N
        jButton3.setLabel("Employee Registration");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 170, -1));

        jLabel10.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel10.setText("Pay group");
        jLabel10.setOpaque(true);
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 160, 110, 30));

        cmb_pgr.setFont(new java.awt.Font("Rockwell Condensed", 0, 14)); // NOI18N
        cmb_pgr.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Comapny 1", "Company 2", "Company 3" }));
        cmb_pgr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_pgrActionPerformed(evt);
            }
        });
        getContentPane().add(cmb_pgr, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 170, 180, -1));
        getContentPane().add(txt_eid, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 40, 170, -1));
        getContentPane().add(txt_jtitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 430, 180, -1));

        jLabel12.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel12.setText("Employee Name");
        jLabel12.setOpaque(true);
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 120, 140, 30));
        getContentPane().add(txt_ename, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 120, 180, -1));

        jLabel13.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel13.setText("Basic Salary");
        jLabel13.setOpaque(true);
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 310, 120, 30));
        getContentPane().add(txt_bsal, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 310, 180, -1));

        jLabel14.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel14.setText("Gender");
        jLabel14.setOpaque(true);
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 260, 70, 30));
        getContentPane().add(txt_gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 270, 180, -1));

        jLabel15.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel15.setText("Employee Type");
        jLabel15.setOpaque(true);
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 390, 130, 30));
        getContentPane().add(txt_etype, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 390, 180, -1));

        jLabel16.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel16.setText("Allowance");
        jLabel16.setOpaque(true);
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 350, 90, 30));
        getContentPane().add(txt_alw, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 350, 180, -1));

        jLabel17.setIcon(new javax.swing.ImageIcon("C:\\Users\\Thilini.piyumika\\Desktop\\PayrollMimages\\human icon2.png")); // NOI18N
        jLabel17.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 130, 130));

        jLabel18.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel18.setText("Employee ID");
        jLabel18.setOpaque(true);
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 100, 30));

        jButton7.setFont(new java.awt.Font("Rockwell Condensed", 0, 18)); // NOI18N
        jButton7.setText("Close");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 480, 100, -1));

        jButton6.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        jButton6.setText("Salary Process");
        jButton6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton6.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 170, 30));

        btn_search.setFont(new java.awt.Font("Rockwell Condensed", 1, 14)); // NOI18N
        btn_search.setText("Search");
        btn_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchActionPerformed(evt);
            }
        });
        getContentPane().add(btn_search, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 80, -1, 20));
        getContentPane().add(txt_age, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 220, 180, -1));

        jLabel20.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel20.setText("Age");
        jLabel20.setOpaque(true);
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 210, 40, 30));

        jLabel1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 18)); // NOI18N
        jLabel1.setText("Home ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, 90, -1));

        jLabel2.setBackground(new java.awt.Color(153, 153, 153));
        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Thilini.piyumika\\Desktop\\PayrollMimages\\How-a-Payroll-System-Works-.png")); // NOI18N
        jLabel2.setOpaque(true);
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 540));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmb_pgrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_pgrActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb_pgrActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        EmployeeRegisterDetails frame1= new EmployeeRegisterDetails();
        frame1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void btn_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchActionPerformed
          Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    try {
        
        int empID = Integer.parseInt(txt_eid.getText());

        
        connection = DB.getConnection();

       
        String sql = "SELECT empName, paygrp, age, gender, Bsal, allowance, emp_type, job_title FROM employee_salary_details WHERE empID = ?";
        preparedStatement = connection.prepareStatement(sql);

        
        preparedStatement.setInt(1, empID);

       
        resultSet = preparedStatement.executeQuery();

        
        if (resultSet.next()) {
            
            txt_ename.setText(resultSet.getString("empName"));
            cmb_pgr.setSelectedItem(resultSet.getString("paygrp"));
            txt_age.setText(String.valueOf(resultSet.getInt("age")));
            txt_gender.setText(resultSet.getString("gender"));
            txt_bsal.setText(String.valueOf(resultSet.getDouble("Bsal")));
            txt_alw.setText(String.valueOf(resultSet.getDouble("allowance")));
            txt_etype.setText(resultSet.getString("emp_type"));
            txt_jtitle.setText(resultSet.getString("job_title"));

        } else {
            
            JOptionPane.showMessageDialog(this, "Employee not found!");
        }

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Please enter a valid employee ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btn_searchActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        SalaryProcess frame2= new SalaryProcess();
        frame2.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    
    public static void main(String args[]) {
         JFrame frame = new JFrame("Image in JLabel Example");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

       
        ImageIcon imageIcon = new ImageIcon("path_to_image/image.png");


       
        frame.setVisible(false);
        java.awt.EventQueue.invokeLater(() -> {
            new Home().setVisible(true);
         });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_search;
    private javax.swing.JComboBox<String> cmb_pgr;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txt_age;
    private javax.swing.JTextField txt_alw;
    private javax.swing.JTextField txt_bsal;
    private javax.swing.JTextField txt_eid;
    private javax.swing.JTextField txt_ename;
    private javax.swing.JTextField txt_etype;
    private javax.swing.JTextField txt_gender;
    private javax.swing.JTextField txt_jtitle;
    // End of variables declaration//GEN-END:variables
}
