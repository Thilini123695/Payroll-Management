
package Views;

import Controller.LoginController;
import Model.LoginModel;
import java.lang.ModuleLayer.Controller;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;


public class Login extends javax.swing.JFrame {

     private LoginController controller;

    // Constructor that accepts the controller
    
    public Login(LoginController controller) {
        
        this.controller = controller;
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollBar1 = new javax.swing.JScrollBar();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Text_pw = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Text_usrn = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 153, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setIcon(new javax.swing.ImageIcon("C:\\Users\\Thilini.piyumika\\Desktop\\PayrollMimages\\pay7.png")); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 220, 210));

        jLabel3.setBackground(new java.awt.Color(204, 204, 204));
        jLabel3.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel3.setText("User Name");
        jLabel3.setToolTipText("");
        jLabel3.setOpaque(true);
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 140, 100, 30));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 24)); // NOI18N
        jLabel2.setText("Payroll Management System");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, 440, 30));

        Text_pw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Text_pwActionPerformed(evt);
            }
        });
        getContentPane().add(Text_pw, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 190, 160, -1));

        jLabel6.setBackground(new java.awt.Color(204, 204, 204));
        jLabel6.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel6.setText("Password");
        jLabel6.setToolTipText("");
        jLabel6.setOpaque(true);
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 180, 100, 30));

        Text_usrn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Text_usrnActionPerformed(evt);
            }
        });
        getContentPane().add(Text_usrn, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 150, 160, -1));

        jButton1.setFont(new java.awt.Font("Rockwell Extra Bold", 0, 18)); // NOI18N
        jButton1.setText("Sign in");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 280, -1, -1));

        jLabel4.setBackground(new java.awt.Color(204, 204, 204));
        jLabel4.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel4.setText("Enter user name and password.");
        jLabel4.setOpaque(true);
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 100, 290, 20));

        jButton2.setFont(new java.awt.Font("Rockwell Extra Bold", 0, 18)); // NOI18N
        jButton2.setText("Login");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 280, -1, -1));

        jLabel7.setBackground(new java.awt.Color(204, 204, 204));
        jLabel7.setOpaque(true);
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 610, 280));

        jLabel1.setBackground(new java.awt.Color(186, 203, 219));
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Thilini.piyumika\\Desktop\\PayrollMimages\\business_finance_theme_1.png")); // NOI18N
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 420));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       Signin frame3 = new Signin();
    frame3.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String username = Text_usrn.getText();
        String password = Text_pw.getText();
        
        
        
        if (controller.validateUser( username, password)){
            JOptionPane.showMessageDialog(this, "Login Sucessful");
            Home home= new Home();
            home.setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Login Failed");
        }

      
      
      
      
    }//GEN-LAST:event_jButton2ActionPerformed

    private void Text_pwActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Text_pwActionPerformed
      
    }//GEN-LAST:event_Text_pwActionPerformed

    private void Text_usrnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Text_usrnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Text_usrnActionPerformed

   
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Text_pw;
    private javax.swing.JTextField Text_usrn;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollBar jScrollBar1;
    // End of variables declaration//GEN-END:variables
}
