
package Views;

import DBconnection.DB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class RegisterEmp extends javax.swing.JFrame {

    
    public RegisterEmp() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btn_update = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cmb_pgr = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        txt_eid = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_ename = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txt_gender = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txt_bsal = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txt_alw = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txt_etype = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txt_jtitle = new javax.swing.JTextField();
        btn_save = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txt_age = new javax.swing.JTextField();

        btn_update.setText("Update");
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("Employee Register");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 200, -1));

        jLabel5.setText("Pay Group");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        cmb_pgr.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Company 1", "Company 2", "Company 3" }));
        getContentPane().add(cmb_pgr, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 180, -1));

        jLabel3.setText("Employee ID");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 70, -1));
        getContentPane().add(txt_eid, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, 170, -1));

        jLabel4.setText("Employee name");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 110, -1));
        getContentPane().add(txt_ename, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 170, 30));

        jLabel6.setText("gender");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 60, -1));
        getContentPane().add(txt_gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 200, 170, -1));

        jLabel8.setText("Basic Salary");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, -1, -1));
        getContentPane().add(txt_bsal, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, 170, -1));

        jLabel9.setText("Allowance");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, -1, -1));
        getContentPane().add(txt_alw, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 290, 170, 30));

        jLabel10.setText("Employee Type");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, -1, -1));
        getContentPane().add(txt_etype, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, 170, -1));

        jLabel11.setText("Job Title");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, -1, -1));
        getContentPane().add(txt_jtitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 380, 170, -1));

        btn_save.setText("save");
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });
        getContentPane().add(btn_save, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 420, -1, -1));

        jLabel7.setText("Age");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, 60, -1));
        getContentPane().add(txt_age, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, 170, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
       Connection connection = null;
    PreparedStatement preparedStatement = null;
        
            try {
        // Step 3: Retrieve form data
        int empID = Integer.parseInt(txt_eid.getText());
        String empName = txt_ename.getText();
        String paygrp = cmb_pgr.getSelectedItem().toString(); 
        int age = Integer.parseInt(txt_age.getText());
        String gender = txt_gender.getText();
        double Bsal = Double.parseDouble(txt_bsal.getText());
        double allowance = Double.parseDouble(txt_alw.getText());
        String empType = txt_etype.getText();
        String jobTitle = txt_jtitle.getText();

        // Step 4: Establish a connection to the database
        connection = DB.getConnection();

        // Step 5: Write the SQL insert query
        String sql = "INSERT INTO employee_salary_details (empID, empName, paygrp, age, gender, Bsal, allowance, emp_type, job_title) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        preparedStatement = connection.prepareStatement(sql);

        // Step 6: Set the values for the prepared statement
        preparedStatement.setInt(1, empID);
        preparedStatement.setString(2, empName);
        preparedStatement.setString(3, paygrp);
        preparedStatement.setInt(4, age);
        preparedStatement.setString(5, gender);
        preparedStatement.setDouble(6, Bsal);
        preparedStatement.setDouble(7, allowance);
        preparedStatement.setString(8, empType);
        preparedStatement.setString(9, jobTitle);

        // Step 7: Execute the insert query
        int rowsInserted = preparedStatement.executeUpdate();

        if (rowsInserted > 0) {
            JOptionPane.showMessageDialog(this, "Employee details saved successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to save employee details.");
        }

    } catch (NumberFormatException ex) {
        // Handle invalid input, e.g., non-numeric values in numeric fields
        JOptionPane.showMessageDialog(this, "Please enter valid data: " + ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
    } catch (SQLException ex) {
        // Handle SQL-related errors
        JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            // Step 8: Close the connection and the prepared statement
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
             
           
    }//GEN-LAST:event_btn_saveActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
       Connection connection = null;
    PreparedStatement preparedStatement = null;

    try {
        // Step 1: Retrieve updated form data
        int empID = Integer.parseInt(txt_eid.getText());
        String empName = txt_ename.getText();
        String paygrp = cmb_pgr.getSelectedItem().toString();
        int age = Integer.parseInt(txt_age.getText());
        String gender = txt_gender.getText();
        double Bsal = Double.parseDouble(txt_bsal.getText());
        double allowance = Double.parseDouble(txt_alw.getText());
        String empType = txt_etype.getText();
        String jobTitle = txt_jtitle.getText();

        // Step 2: Establish a connection to the database
        connection = DB.getConnection();

        // Step 3: Write the SQL update query
        String sql = "UPDATE employee_salary_details SET empName = ?, paygrp = ?, age = ?, gender = ?, Bsal = ?, allowance = ?, emp_type = ?, job_title = ? WHERE empID = ?";
        preparedStatement = connection.prepareStatement(sql);

        // Step 4: Set the values for the prepared statement
        preparedStatement.setString(1, empName);
        preparedStatement.setString(2, paygrp);
        preparedStatement.setInt(3, age);
        preparedStatement.setString(4, gender);
        preparedStatement.setDouble(5, Bsal);
        preparedStatement.setDouble(6, allowance);
        preparedStatement.setString(7, empType);
        preparedStatement.setString(8, jobTitle);
        preparedStatement.setInt(9, empID);  // The empID in the WHERE clause

        // Step 5: Execute the update query
        int rowsUpdated = preparedStatement.executeUpdate();

        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, "Employee details updated successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update employee details.");
        }

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Please enter valid data: " + ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        
    
          
    }//GEN-LAST:event_btn_updateActionPerformed
}

  



    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegisterEmp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegisterEmp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegisterEmp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegisterEmp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegisterEmp().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_update;
    private javax.swing.JComboBox<String> cmb_pgr;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txt_age;
    private javax.swing.JTextField txt_alw;
    private javax.swing.JTextField txt_bsal;
    private javax.swing.JTextField txt_eid;
    private javax.swing.JTextField txt_ename;
    private javax.swing.JTextField txt_etype;
    private javax.swing.JTextField txt_gender;
    private javax.swing.JTextField txt_jtitle;
    // End of variables declaration//GEN-END:variables
}
